package com.example.myapplication.MyApplication5;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.myapplication.R;

public class TodoDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_details);

        // Retrieve data from Intent
        int userId = getIntent().getIntExtra("userId", 0);
        int id = getIntent().getIntExtra("id", 0);
        String title = getIntent().getStringExtra("title");
        boolean completed = getIntent().getBooleanExtra("completed", false);

        // Display data in TextViews
        TextView userIdTextView = findViewById(R.id.userIdTextView);
        TextView idTextView = findViewById(R.id.idTextView);
        TextView titleTextView = findViewById(R.id.titleTextView);
        TextView completedTextView = findViewById(R.id.completedTextView);

        userIdTextView.setText("User ID: " + userId);
        idTextView.setText("ID: " + id);
        titleTextView.setText("Title: " + title);
        completedTextView.setText("Completed: " + completed);
    }
}
